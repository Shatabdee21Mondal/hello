package org.capgemini.ems.dao;

import org.capgemini.ems.bean.UserMasterBean;

public interface ILoginDAO {
	public boolean isValidLogin(UserMasterBean userMasterBean);

}
