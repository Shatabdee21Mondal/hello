package org.capgemini.ems.service;

import org.capgemini.ems.bean.UserMasterBean;

public class LoginServiceImpl implements ILoginService{

	@Override
	public boolean isValidLogin(UserMasterBean userMasterBean) {
		
		return false;
	}

}
