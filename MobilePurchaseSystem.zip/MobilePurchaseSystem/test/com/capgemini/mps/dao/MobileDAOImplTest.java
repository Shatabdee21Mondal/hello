package com.capgemini.mps.dao;

import static org.junit.Assert.fail;
import static org.junit.Assert.assertNotNull;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.mps.exception.MobilePurchaseSystemException;
import com.capgemini.mps.util.DBConnection;

public class MobileDAOImplTest {

	@BeforeClass
	public static void testDBConnection() {
		try {
			System.out.println("Before class method");
			Connection connection = DBConnection.getConnection();
			assertNotNull(connection);
		} catch (MobilePurchaseSystemException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	
	/*@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}*/
	@Ignore
	@Test
	public void testDeleteMobile() {
		fail("Not yet implemented");
	}
	@Ignore
	@Test
	public void testGetAllMobileDetails() {
		fail("Not yet implemented");
	}
	@Ignore
	@Test
	public void testGetMobilesPriceRange() {
		fail("Not yet implemented");
	}

}
