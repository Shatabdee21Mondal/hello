package com.capgemini.mps.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class CustomerValidatorTest {

	/*@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}*/

	@Test
	public void testIsValidCustomerName() {
		assertTrue(new CustomerValidator().isValidCustomerName("Shatabdee Mondal"));
	}
	@Test
	public void testIsNotValidCustomerName() {
		assertFalse(new CustomerValidator().isValidCustomerName("Shatabdee Mondal jmksdkmk"));
	}
	
	@Test
	public void testIsValidCustomerEmail() {
		assertTrue(new CustomerValidator().isValidCustomerEmail("shatabdee.mondal@gmail.com"));
	}
	@Test
	public void testIsNotValidCustomerEmail() {
		assertFalse(new CustomerValidator().isValidCustomerEmail("shatabdee.mondal@gmail@com"));
	}
	
	@Test
	public void testIsValidCustomerMobile() {
		assertTrue(new CustomerValidator().isValidCustomerMobile(9705409887L));
	}
	@Test
	public void testIsNotValidCustomerMobile() {
		assertFalse(new CustomerValidator().isValidCustomerMobile(21099712156526326L));
	}

}
