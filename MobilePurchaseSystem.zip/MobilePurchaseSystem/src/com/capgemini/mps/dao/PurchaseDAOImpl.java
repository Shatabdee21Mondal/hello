package com.capgemini.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.mps.exception.MobilePurchaseSystemException;
import com.capgemini.mps.util.DBConnection;

public class PurchaseDAOImpl  implements IPurchaseDAO{
	private static Logger myDAOLogger=Logger.getLogger(MobileDAOImpl.class);
	@Override
	public Integer addPurchaseDetails(String name, String emailId,
			Long phoneNumber, Integer mobileId) throws MobilePurchaseSystemException{
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.ADD_PURCHASE_DETAILS);
				Statement statement=connection.createStatement();
			){
			//System.out.println("landed in dao");
				preparedStatement.setString(1, name);
				preparedStatement.setString(2, emailId);
				preparedStatement.setLong(3,phoneNumber);
				preparedStatement.setInt(4,mobileId);
				int n=preparedStatement.executeUpdate();
				//System.out.println("im executed");
				if(n>0){
					new MobileDAOImpl().updateMobileQuantity(mobileId, 1);
					ResultSet resultSet=statement.executeQuery(QueryMapper.RETRIEVE_PURCHASEID);
					if(resultSet.next()){
						Integer purchaseId=resultSet.getInt(1);
						return purchaseId;
					}/*else{
						return null;
					}*/
					
				}else{
					myDAOLogger.info("Unable to add purchase details");
					//myDAOLogger.error(e.getMessage());
					System.out.println(n);
					throw new MobilePurchaseSystemException("Technical error.. Contact to logs");
				}
			
		}catch(SQLException e){
			myDAOLogger.error(e.getMessage());
			throw new MobilePurchaseSystemException("Technical Error.. Contact to logs");
		}
		return null;

	}
}
