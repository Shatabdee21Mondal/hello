package com.capgemini.mps.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.mps.bean.Mobile;
import com.capgemini.mps.exception.MobilePurchaseSystemException;
import com.capgemini.mps.service.CustomerValidator;
import com.capgemini.mps.service.IMobileService;
import com.capgemini.mps.service.IPurchaseService;
import com.capgemini.mps.service.MobileServiceImpl;
import com.capgemini.mps.service.PurchaseServiceImpl;


public class MPSTester {
	private static Scanner scanner = new Scanner(System.in);
	private  static IMobileService mobileService=new MobileServiceImpl();
	private static IPurchaseService purchaseService=new PurchaseServiceImpl();
	private static Logger myUILogger=Logger.getLogger(MPSTester.class);
	
	public static void main(String args[]){
		PropertyConfigurator.configure("resource/log4j.properties");
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Mobile Purchase System ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Mobile ");
			System.out.println("2.Search Mobile Based On Price Range");
			System.out.println("3.Retrive All Mobiles");
			System.out.println("4.Delete Mobile");
			System.out.println("5.Purchase Mobile");
			System.out.println("6.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				int option = scanner.nextInt();

				switch (option) {

				case 1:
					//TODO
					break;
				case 2:
					System.out.println("Enter Lower-limit and Upper-limit price:");
					double lowPrice=scanner.nextDouble();
					double highPrice=scanner.nextDouble();
					List<Mobile> mobileRangeList=getMobilesPriceRange(lowPrice,highPrice);
					showMobiles(mobileRangeList);
					break;
				case 3:
					List<Mobile> mobileList=getAllMobileDetails();
					showMobiles(mobileList);
					break;
				case 4:
					System.out.println("Enter mobile Id:");
					int mobileId=scanner.nextInt();
					String status=deleteMobile(mobileId);
					System.out.println(status);
					break;
				case 5:
					System.out.println("Enter  10 digit phone number:");
					Long phoneNumber=scanner.nextLong();
					System.out.println("Enter customer name(begin with uppercase and name should not exceed 20 characters:");
					String name=scanner.next();
					scanner.nextLine();// clear keyboard buffer
					System.out.println("Enter EmailId:");
					String emailId=scanner.nextLine();
					CustomerValidator validator=new CustomerValidator();
					if(validator.isValidCustomerName(name)){
						if(validator.isValidCustomerEmail(emailId)){
							if(validator.isValidCustomerMobile(phoneNumber)){
								/*PurchaseDetails purchaseDetails=new PurchaseDetails();
								purchaseDetails.setCustomerName(name);
								purchaseDetails.setEmailId(emailId);
								purchaseDetails.setPhoneNumber(phoneNumber);*/
								System.out.println("Enter mobileId");
								Integer mId=scanner.nextInt();
								try {
									if(mobileService.isValidMobileId(mId)){
										/*purchaseDetails.setMobileId(mId);*/
										Integer purchaseId=addPurchaseDetails(name,emailId,phoneNumber,mId);
										//System.out.println("Purchase Id:"+purchaseId);
										
									}else{
										System.out.println("Enter valid mobile id!!");
									}
								} catch (MobilePurchaseSystemException e) {
									
									System.out.println(e.getMessage());
								}
								
							}else{
								System.out.println("Enter valid Phone Number!!");
							}
						}else{
							System.out.println("Enter valid Email Id!!");
						}
					}else{
						System.out.println("Enter valid Customer Name!!");
					}
					break;
				case 6:

					System.out.print("Exit Mobile Purchase System:");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-6]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				myUILogger.warn("Enter only integer value[1-6]!!!");
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try
	private static Integer addPurchaseDetails(String name, String emailId,Long phoneNumber, int mobileId) {
		try {
			Integer purchaseId= purchaseService.addPurchaseDetails(name, emailId, phoneNumber, mobileId);
			System.out.println("Presentation Layer:"+ purchaseId);
			return purchaseId;
		} catch (MobilePurchaseSystemException e) {
			myUILogger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return null;
		
	}
	private static String deleteMobile(int mobileId) {
		
		try {
			String status=mobileService.deleteMobile(mobileId);
			return status;
		} catch (MobilePurchaseSystemException e) {
			myUILogger.error(e.getMessage());
			myUILogger.info("Enter valid mobileid");
			myUILogger.warn("Enter valid mobileid");
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	private static List<Mobile> getMobilesPriceRange(double lowPrice,double highPrice) {
	
		try {
			return mobileService.getMobilesPriceRange(lowPrice, highPrice);
		} catch (MobilePurchaseSystemException e) {
			myUILogger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		return null;
	}
	private static void showMobiles(List<Mobile> mobileList) {
		if(mobileList!=null){
			Iterator<Mobile> iterator=mobileList.iterator();
			while(iterator.hasNext()){
				System.out.println(iterator.next());
			}
		}else{
			System.out.println("No data found");
		}
		
	}
	private static List<Mobile> getAllMobileDetails() {
		try {
			List<Mobile> mobileList=mobileService.getAllMobileDetails();
			return mobileList;
		} catch (MobilePurchaseSystemException e) {
			myUILogger.error(e.getMessage());
			System.out.println("Exception occured:");
			e.printStackTrace();
		}
		return null;
		
	}


}

