package com.capgemini.mps.service;

import java.util.List;

import com.capgemini.mps.bean.Mobile;
import com.capgemini.mps.exception.MobilePurchaseSystemException;

public interface IMobileService {
	public abstract String deleteMobile(Integer mobilId) throws MobilePurchaseSystemException;
	public abstract List<Mobile> getAllMobileDetails() throws MobilePurchaseSystemException;
	public abstract List<Mobile> getMobilesPriceRange(Double lowPrice,Double highPrice) throws MobilePurchaseSystemException;
	public Boolean isValidMobileId(Integer mobileId) throws MobilePurchaseSystemException;

}
