package com.capgemini.mps.service;

import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.mps.bean.Mobile;
import com.capgemini.mps.dao.IPurchaseDAO;
import com.capgemini.mps.dao.MobileDAOImpl;
import com.capgemini.mps.dao.PurchaseDAOImpl;
import com.capgemini.mps.exception.MobilePurchaseSystemException;

public class PurchaseServiceImpl implements IPurchaseService{
	private static Logger myServiceLogger=Logger.getLogger(PurchaseServiceImpl.class);
	
	IPurchaseDAO purchaseDAO=new PurchaseDAOImpl();
	
	@Override
	public Integer addPurchaseDetails(String name,String emailId,Long phoneNumber, Integer mobileId) throws MobilePurchaseSystemException {
		try{
			System.out.println("im in service");
			Mobile mobile=new MobileDAOImpl().getMobileDetails(mobileId);
			if(mobile.getQuantity()>0){
				System.out.println("calling dao");
				Integer purchaseId=purchaseDAO.addPurchaseDetails(name, emailId, phoneNumber, mobileId);
				//System.out.println("Service Layer:"+purchaseId);
				return purchaseId;
			}else{
				throw new MobilePurchaseSystemException("No Stock");
			}
			
		}catch(MobilePurchaseSystemException e){
			myServiceLogger.error(e.getMessage());
			myServiceLogger.warn("Enter valid mobileid");
			throw new MobilePurchaseSystemException("Techincal error... Contact to logs");
		}

	}
}
