package com.capgemini.mps.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.regex.Pattern;

/**
 * 
 * @author shamonda
 *This class validates the date fileds of customre class
 */
public class CustomerValidator {

	/**
	 * 
	 * @param customer
	 * @return true if customer name is a sequence of alphabets,
	 * one or no space else return false
	 */
	public Boolean isValidCustomerName(String name){
		String regex="^[A-Z][a-zA-Z\\s]{0,19}$";
		//System.out.println(name);
		//return true;
		return Pattern.matches(regex, name);
	}
	
	
	
	/**
	 * 
	 * @param customer
	 * @return true if email is valid else return false.
	 * email validity:
	 * 1. email begins with either digits or alphabets followed
	 * one @ symbol followed by domain name followed by dot(.)
	 * operator followed by 2 or 3 characters followed by dot(.) operator followed by 2 characters
	 * the second dot operator followed by 2 characters is optional
	 */
	public Boolean isValidCustomerEmail(String emailId){
		
		String regex=/*"^[a-zA-Z0-9._]+[@][a-zA-Z]+[.][a-zA-Z]{2,3}";*/
			"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"; 
					return Pattern.matches(regex,emailId); 
				
	}
	
	/**
	 * 
	 * @param customer
	 * @return true if mobile number is 10-digit number
	 * else return false
	 */
	public Boolean isValidCustomerMobile(Long phoneNumber){
		 String mobile= phoneNumber.toString(phoneNumber);
		 String regex="^[1-9]{1}[0-9]{9}$";
		 return Pattern.matches(regex,mobile);
	}
	
	public Boolean isValidCustomerMobilId(Integer mobileId){
		String mobileIdString=mobileId.toString(mobileId);
		String regex="^[1-9][0-9]{3}$";
		return Pattern.matches(regex,mobileIdString);
	}

}
