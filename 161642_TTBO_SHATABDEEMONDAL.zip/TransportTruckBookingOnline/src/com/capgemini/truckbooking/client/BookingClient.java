package com.capgemini.truckbooking.client;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;






import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.service.BookingService;
import com.capgemini.truckbooking.service.IBookingService;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;


public class BookingClient {
	private static Scanner scanner = new Scanner(System.in);
	private  static ITruckService truckService=new TruckService();
	private static BookingService bookingService=new BookingService();
	private static Logger myUILogger=Logger.getLogger(BookingClient.class);

	public static void main(String[] args) {
		PropertyConfigurator.configure("resource/log4j.properties");
		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println(" Transport Truck Booking Online ");
			System.out.println("_______________________________\n");

			System.out.println("MENU");
			System.out.println("1.Book Trucks");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				int option = scanner.nextInt();

				switch (option) {
				case 1:
					System.out.println("Enter Cust Id:");
					String custId=scanner.next();
					List<TruckBean> truckList=retrieveTruckDetails();
					showTrucks(truckList);
					System.out.println("Enter Truck Id:");
					Integer truckId=scanner.nextInt();
					scanner.nextLine();// clear keyboard buffer
					System.out.println("Enter Number of trucks to be booked:");
					Integer noOfTrucks=scanner.nextInt();
					scanner.nextLine();// clear keyboard buffer
					System.out.println("Enter Customer mobile number");
					Long custMobile=scanner.nextLong();
					System.out.println("Enter date of transportation");
					String dateOfTransportation=scanner.next();
					System.out.println("Thank You your booking id is");
					break;
					
				case 2:
					System.out.print("Exited  from Transport Truck Booking Online System:");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-2]");
				}// end of switch



			}catch (InputMismatchException e) {
				myUILogger.warn("Enter only integer value[1-5]!!!");
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}


		}
	}
		private static void showTrucks(List<TruckBean> truckList) {
			if(truckList!=null){
				Iterator<TruckBean> iterator=truckList.iterator();
				while(iterator.hasNext()){
					System.out.println(iterator.next());
				}
			}else{
				System.out.println("No data found");
			}
		}



		private static List<TruckBean> retrieveTruckDetails() {
			try {
				List<TruckBean> truckList=truckService.retrieveTruckDetails();
				return truckList;
			} catch (BookingException e) {
				myUILogger.error(e.getMessage());
				System.out.println("Exception occured:");
				e.printStackTrace();
			}
			return null;

		}
	}


