package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.util.DBConnection;

public class TruckDao implements ITruckDao{
	private static Logger myDAOLogger=Logger.getLogger(TruckDao.class);
	int truckCount=0;

	@Override
	public int getBookingId() throws BookingException {
		
		return 0;
	}

	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		try(
				Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			ResultSet resultSet=statement.executeQuery(QueryMapper.RETRIVE_ALL_TRUCKDETAILS);
			List<TruckBean> truckList=new ArrayList<>();
			while(resultSet.next()){
				truckCount++;
				TruckBean truck=new TruckBean();					
				populateTruck(truck,resultSet);
				truckList.add(truck);
			}
			if(truckCount!=0){
				return truckList;
			}else{
				return null;
			}
		}catch(SQLException e){
			myDAOLogger.error(e.getMessage());
			throw new BookingException("Technical error!! Refer to Logs");
			//e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}

		return null;
	}
	private void populateTruck(TruckBean truck, ResultSet resultSet) throws SQLException {
		truck.setTruckID(resultSet.getInt("truckId"));
		truck.setTruckType(resultSet.getString("truckType"));
		truck.setOrigin(resultSet.getString("origin"));
		truck.setDestination(resultSet.getString("destination"));
		truck.setCharges(resultSet.getFloat("charges"));
		truck.setAvailableNos(resultSet.getInt("availableNos"));
			
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		
		return 0;
	}
	public Integer updateTrucks(Integer truckId, Integer  availableNos) throws BookingException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_TRUCKS);
				
			){
				preparedStatement.setInt(1,availableNos);
				preparedStatement.setInt(2,truckId);
				int n=preparedStatement.executeUpdate();
				return n;
				
		}catch(SQLException e){
			myDAOLogger.error(e.getMessage());
			throw new BookingException("Techincal Error.. Refer to log");
		}
	}

}
