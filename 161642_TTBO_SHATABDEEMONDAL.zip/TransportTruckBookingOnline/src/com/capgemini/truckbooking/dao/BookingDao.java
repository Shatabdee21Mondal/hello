package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.exception.BookingException;
import com.capgemini.truckbooking.util.DBConnection;



public class BookingDao {
	private static Logger myDAOLogger=Logger.getLogger(TruckDao.class);
	public Integer addBookingDetails(int truckId,int noOfTrucks,long custMobile,
			Date dateOfTransport) throws BookingException{
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.ADD_PURCHASE_DETAILS);
				Statement statement=connection.createStatement();
				){
			//System.out.println("landed in dao");
			preparedStatement.setInt(1, truckId);
			preparedStatement.setInt(2, noOfTrucks);
			preparedStatement.setLong(3,custMobile);
			preparedStatement.setDate(4,dateOfTransport);
			int n=preparedStatement.executeUpdate();
			//System.out.println("im executed");
			if(n>0){
				new TruckDao().updateTrucks(truckId, 1);
				ResultSet resultSet=statement.executeQuery(QueryMapper.RETRIEVE_TRUCKID);
				if(resultSet.next()){
					Integer purchaseId=resultSet.getInt(1);
					return purchaseId;
				}/*else{
						return null;
					}*/

			}else{
				myDAOLogger.info("Unable to add purchase details");
				//myDAOLogger.error(e.getMessage());
				System.out.println(n);
				throw new BookingException("Technical error.. Contact to logs");
			}

		}catch(SQLException e){
			myDAOLogger.error(e.getMessage());
			throw new BookingException("Technical Error.. Contact to logs");
		}
		return null;

	}
	public Integer updateTrucks(Integer truckId, Integer availableNos)
			throws BookingException {
		try(Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_TRUCKS);

				){
			preparedStatement.setInt(1, truckId);
			preparedStatement.setInt(2, availableNos);

			int n=preparedStatement.executeUpdate();
			if(n>0){
				return n;
			}
		}catch(SQLException e){
			//myMobDAOLogger.error(e.getMessage());
			e.printStackTrace();

		}catch(Exception e){
			//myMobDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		return null;

	}



}


