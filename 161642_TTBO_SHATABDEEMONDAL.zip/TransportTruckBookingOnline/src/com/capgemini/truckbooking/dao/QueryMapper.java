package com.capgemini.truckbooking.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_TRUCKDETAILS="SELECT * FROM TruckDetails";
	public static final String ADD_PURCHASE_DETAILS="INSERT INTO BookingDetails "
					+ "	VALUES(booking_id_seq.NEXTVAL,?,?,?,?,SYSDATE,?)";
	public static final String UPDATE_TRUCKS="UPDATE TruckDetails SET availableNos=availableNos-? "
			+ "where truckId=?";
	public static final String RETRIEVE_TRUCKID="SELECT booking_id_seq.CURRVAL from dual";
	
	
}
