package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;

import com.capgemini.truckbooking.exception.BookingException;




public interface IBookingDao {
	public Integer addBookingDetails(int truckId,int noOfTrucks,long custMobile,
			LocalDate dateOfTransport) throws BookingException;

	public Integer addPurchaseDetails(int truckId, int noOfTrucks,
			long custMobile, LocalDate dateOfTransport);		
		
	

}
