package com.capgemini.truckbooking.service;

import java.time.LocalDate;

import com.capgemini.truckbooking.exception.BookingException;


public interface IBookingService {
	public Integer addBookingDetails(int truckId,int noOfTrucks,long custMobile,
			LocalDate dateOfTransport) throws BookingException;

}
