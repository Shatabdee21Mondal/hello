package com.capgemini.truckbooking.service;

import java.util.List;



import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;

public class TruckService  implements ITruckService{
	private TruckDao truckDAO=new TruckDao();
	@Override
	public List<TruckBean> retrieveTruckDetails() throws BookingException {
		List<TruckBean> truckList=truckDAO.retrieveTruckDetails();
		return truckList;
	}

	@Override
	public int bookTrucks(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
