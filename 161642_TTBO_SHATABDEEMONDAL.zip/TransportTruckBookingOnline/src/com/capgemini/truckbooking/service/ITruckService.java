package com.capgemini.truckbooking.service;

import java.util.List;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.BookingException;

public interface ITruckService {
	List<TruckBean> retrieveTruckDetails() throws BookingException;
	int bookTrucks(BookingBean bookingBean) throws BookingException;	
}
