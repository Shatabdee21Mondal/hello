package com.capgemini.truckbooking.service;

import java.time.LocalDate;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.dao.BookingDao;
import com.capgemini.truckbooking.dao.IBookingDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.BookingException;


public class BookingService implements IBookingDao{

	@Override
	public Integer addBookingDetails(int truckId, int noOfTrucks,
			long custMobile, LocalDate dateOfTransport) throws BookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer addPurchaseDetails(int truckId, int noOfTrucks,
			long custMobile, LocalDate dateOfTransport) {
		// TODO Auto-generated method stub
		return null;
	}
/*private static Logger myServiceLogger=Logger.getLogger(BookingService.class);
	
	IBookingDao bookingDAO=(IBookingDao) new BookingDao();
	
	@Override
	public Integer addBookingDetails(int truckId,int noOfTrucks,long custMobile,
			LocalDate dateOfTransport) throws BookingException{
		try{
			Object custId;
			//System.out.println("im in service");
			TruckBean truck=new TruckBean();
			if(truck.getTruckID()>0){
				//System.out.println("calling dao");
				Integer purchaseId=bookingDAO.addPurchaseDetails(truckId,noOfTrucks,custMobile,dateOfTransport);
				//System.out.println("Service Layer:"+purchaseId);
				return purchaseId;
			}else{
				throw new BookingException("No Stock");
			}
			
		}catch(BookingException e){
			myServiceLogger.error(e.getMessage());
			myServiceLogger.warn("Enter valid mobileid");
			throw new BookingException("Techincal error... Contact to logs");
		}

	}

	@Override
	public Integer addPurchaseDetails(int truckId, int noOfTrucks,
			long custMobile, LocalDate dateOfTransport) {
		// TODO Auto-generated method stub
		return null;
	}*/
}
