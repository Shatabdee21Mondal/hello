package com.capgemini.truckbooking.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.regex.Pattern;

/**
 * 
 * @author shamonda
 *This class validates the date fileds of customre class
 */
public class CustomerValidator {

	/**
	 * 
	 * @param customerId
	 * @return true if customer id should upper case 1st letter followed by 6 digits,
	 * one or no space else return false
	 */
	public Boolean isValidCustomerId(String custId){
		String regex="^[A-Z]{1}[0-9]{1,6}$";
		//System.out.println(name);
		//return true;
		return Pattern.matches(regex, custId);
	}

}
