package com.capgemini.example.dao;

import com.capgemini.example.bean.Customer;
import com.capgemini.example.bean.PizzaOrder;
import com.capgemini.example.exception.PizzaOrderException;

public interface IPizzaOrderDAO {
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaOrderException;
	public PizzaOrder getOrderDetails(int orderid) throws PizzaOrderException;

}
