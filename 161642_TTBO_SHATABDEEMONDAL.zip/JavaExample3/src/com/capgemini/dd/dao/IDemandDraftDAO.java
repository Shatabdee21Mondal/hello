package com.capgemini.dd.dao;

import com.capgemini.dd.bean.DemandDraft;

public interface IDemandDraftDAO {
	
	public int addDemandDraftDetails(DemandDraft demandDraft);
	public DemandDraft getDemandDraftDetails(int transactionId);
	

}
