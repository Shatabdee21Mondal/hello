package com.capgemini.dd.exceptions;

public class InvalidAmountException extends Exception {
	
	
	//create a user defined exception
	public InvalidAmountException(String message)	{
		super(message);
	}

}
