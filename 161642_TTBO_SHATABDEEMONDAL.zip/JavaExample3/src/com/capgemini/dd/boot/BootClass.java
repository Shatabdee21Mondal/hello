package com.capgemini.dd.boot;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.dd.bean.DemandDraft;
import com.capgemini.dd.service.DemandDraftService;
import com.capgemini.dd.service.IDemandDraftService;
import com.capgemini.dd.ui.UserInteraction;


//log4j.properties file also added in src/test/resources
public class BootClass {
	final static Logger logger=Logger.getLogger(BootClass.class);

	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		UserInteraction userInteraction=new UserInteraction();//route to userInteraction layer to prompt the details
		DemandDraft demandDraft=new DemandDraft();
		IDemandDraftService demandDraftService=new DemandDraftService();
		
		int choice;
		do {
			System.out.println("Choose the option : - ");
			System.out.println("1. Enter Demand Draft Details");
			System.out.println("2. Exit");
			choice=scanner.nextInt();
			
			if(choice==1) {
				
				demandDraft=userInteraction.getDetails();
				logger.info("Demand draft details fetched from user");
				demandDraftService.addDemandDraftDetails(demandDraft);
				System.out.println("Your demand draft request has been successsfully registered!!!");
				logger.info("Demand draft details added to db");
				
				
				
			}
			
			else if(choice==2)
				System.exit(0);
			
			

		}while(choice!=2);
		

	}

}
