package com.capgemini.pizza.bean;

public class Pizza {
	private String pizzaName;
	private Double pizzaPrice;
	private Integer quantity;
	public Pizza() {
		super();
	}
	public Pizza(String pizzaName, Double pizzaPrice, Integer quantity) {
		super();
		this.pizzaName = pizzaName;
		this.pizzaPrice = pizzaPrice;
		this.quantity = quantity;
	}
	public String getPizzaName() {
		return pizzaName;
	}
	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}
	public Double getPizzaPrice() {
		return pizzaPrice;
	}
	public void setPizzaPrice(Double pizzaPrice) {
		this.pizzaPrice = pizzaPrice;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Pizza "
				+ "pizzaName=" + getPizzaName() + ", "
				+ "pizzaPrice=" + getPizzaPrice()
				+ ", quantity=" + getQuantity();
	}
	
	

}
