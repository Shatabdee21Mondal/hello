package com.capgemini.pizza.dao;

import java.sql.SQLException;


import java.util.List;

import com.capgemini.pizza.bean.Pizza;
import com.capgemini.pizza.bean.PizzaOrder;
import com.capgemini.pizza.exception.PizzaException;

public interface IOrderDetailsDAO {
	public abstract PizzaOrder getOrderDetails(Long orderId)throws PizzaException;
	public abstract Long placeOrder(Long customerId,Double totalPrice)throws PizzaException,SQLException;
	public abstract Integer updateQuantity(String pname,Integer quantity) throws PizzaException;
	public abstract boolean isValidOrderId(Long orderId)throws PizzaException;
	public abstract List<Pizza> getPizzaDetails() throws PizzaException;

}
