package com.capgemini.TransportTruck.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.capgemini.TransportTruck.bean.BookingDetails;
import com.capgemini.TransportTruck.bean.TruckDetails;
import com.capgemini.TransportTruck.exception.TransportTruckException;




public interface ITruckdetails {
	public List<TruckDetails> getTruckDetails() throws TransportTruckException ;
	public Integer trucksAvailable(Integer truckId) throws TransportTruckException;
	public Long getBookingId(String custId,
			Long custMobile,Integer noOfTrucks,Integer truckId,Date date) throws TransportTruckException;
	public  Integer updateQuantity(Integer noOfTrucks,Integer truckId)
			throws TransportTruckException;
	
	

}
