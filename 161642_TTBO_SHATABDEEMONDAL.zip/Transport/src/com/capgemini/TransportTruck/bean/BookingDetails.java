package com.capgemini.TransportTruck.bean;

import java.sql.Date;

public class BookingDetails {
	
	private Integer bookingId;
	private String custId;
	private Long custMobile;
	private Integer truckId;
	private Integer noOfTrucks;
	private Date date;
	public BookingDetails() {
		super();
	}
	public BookingDetails(Integer bookingId, String custId, Long custMobile,
			Integer truckId, Integer noOfTrucks) {
		super();
		this.bookingId = bookingId;
		this.custId = custId;
		this.custMobile = custMobile;
		this.truckId = truckId;
		this.noOfTrucks = noOfTrucks;
	}
	public Integer getBookingId() {
		return bookingId;
	}
	public void setBookingId(Integer bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public Long getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(Long custMobile) {
		this.custMobile = custMobile;
	}
	public Integer getTruckId() {
		return truckId;
	}
	public void setTruckId(Integer truckId) {
		this.truckId = truckId;
	}
	public Integer getNoOfTrucks() {
		return noOfTrucks;
	}
	public void setNoOfTrucks(Integer noOfTrucks) {
		this.noOfTrucks = noOfTrucks;
	}
	
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "BookingDetails [bookingId=" + bookingId + ", custId=" + custId
				+ ", custMobile=" + custMobile + ", truckId=" + truckId
				+ ", noOfTrucks=" + noOfTrucks + "]";
	}
	
	
	

}
