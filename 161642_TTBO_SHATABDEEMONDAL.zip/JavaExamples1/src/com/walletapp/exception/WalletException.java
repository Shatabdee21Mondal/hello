package com.walletapp.exception;

public class WalletException extends Exception{
	private static final long serialVersionUID = 726264577455921591L;

public WalletException() {
	super();
}
public WalletException(String message) {
	super(message);
}
}
