package com.walletapp.dao;

public interface QuerryMapper {
	public static final String INSERT_QUERY="INSERT INTO CustomerDetails VALUES(accountnumber_sequence.NEXTVAL,?,?,?,?,?,?,?,?)";
	public static final String ACCOUNTNUMBER_QUERY_SEQUENCE="SELECT accountnumber_sequence.CURRVAL FROM DUAL";
 public static final String SELECT_QUERY="select * from CustomerDetails where accountnumber=?";
 public static final String UPDATE_QUERY="update CustomerDetails set balance=? where accountnumber=?";
 public static final String TRANSINSERT_QUERY="insert into transdetails values(transId_sequence.NEXTVAL,?,?,?,?)";
 public static final String TRANSID_QUERY_SEQUENCE="SELECT transid_sequence.CURRVAL FROM DUAL";
 public static final String TRANSSELECT_QUERY="select * from transdetails where accountnumber=?";
}
/*create table customerdetails(accountnumber number(20),age varhcar(10),customername varchar(20),
 * balance number(20),address varchar(20),mobilenumber varchar(20),accounttype varchar(30),
 * gender varchar(10),atmpin varchar(10));
 * */
 
 
 
 /*create table transdetails(transid number(20),accountnumber number(20),transtype varchar(20),
  * balance number(20), transdate date);
  */
 